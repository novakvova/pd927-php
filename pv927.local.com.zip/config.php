<?php
define('DB_NAME','pv927');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_HOST','localhost');
define('DB_CHARSET','utf8');
define('DB_DRIVER','mysql');
?>